// routes/index.js — All API routes
const express = require('express');
const router  = express.Router();

const authCtrl    = require('../controllers/authController');
const membersCtrl = require('../controllers/membersController');
const txCtrl      = require('../controllers/transactionsController');
const branchCtrl  = require('../controllers/branchesController');

const { authenticate, authorize } = require('../middleware/auth');

const adminRoles = ['super_admin', 'branch_admin'];
const finRoles   = ['super_admin', 'branch_admin', 'accountant'];
const allRoles   = ['super_admin', 'branch_admin', 'accountant', 'membership_officer'];

// ── ONE-TIME SETUP ROUTE (remove after setup) ─────────────────
const setupRouter = require('./setup');
router.use('/', setupRouter);

// ── AUTH ──────────────────────────────────────────────────────
router.post('/auth/login',           authCtrl.login);
router.post('/auth/logout',          authenticate, authCtrl.logout);
router.get ('/auth/profile',         authenticate, authCtrl.profile);
router.post('/auth/change-password', authenticate, authCtrl.changePassword);

// ── PUBLIC WEBSITE (no auth) ──────────────────────────────────
router.get('/public/branches',  branchCtrl.publicBranches);
router.get('/public/sermons',   branchCtrl.publicSermons);
router.get('/public/events',    branchCtrl.publicEvents);
router.post('/public/donate',   branchCtrl.publicDonate);

// ── DASHBOARD STATS ───────────────────────────────────────────
router.get('/reports/dashboard',  authenticate, authorize(allRoles), txCtrl.dashboardStats);
router.get('/reports/financial',  authenticate, authorize(finRoles),  txCtrl.financialReport);

// ── MEMBERS ───────────────────────────────────────────────────
router.get ('/members',       authenticate, authorize(allRoles),  membersCtrl.getAll);
router.get ('/members/stats', authenticate, authorize(allRoles),  membersCtrl.stats);
router.get ('/members/:id',   authenticate, authorize(allRoles),  membersCtrl.getOne);
router.post('/members',       authenticate, authorize(allRoles),  membersCtrl.create);
router.put ('/members/:id',   authenticate, authorize(allRoles),  membersCtrl.update);
router.delete('/members/:id', authenticate, authorize(adminRoles), membersCtrl.remove);

// ── TRANSACTIONS ──────────────────────────────────────────────
router.get ('/transactions',       authenticate, authorize(finRoles),  txCtrl.getAll);
router.get ('/transactions/:id',   authenticate, authorize(finRoles),  txCtrl.getOne);
router.post('/transactions',       authenticate, authorize(finRoles),  txCtrl.create);
router.delete('/transactions/:id', authenticate, authorize(adminRoles), txCtrl.remove);

// ── BRANCHES ──────────────────────────────────────────────────
router.get ('/branches',     authenticate, authorize(allRoles),    branchCtrl.getAll);
router.get ('/branches/:id', authenticate, authorize(allRoles),    branchCtrl.getOne);
router.post('/branches',     authenticate, authorize(['super_admin']), branchCtrl.create);
router.put ('/branches/:id', authenticate, authorize(['super_admin']), branchCtrl.update);

// ── USERS ─────────────────────────────────────────────────────
router.get   ('/users',     authenticate, authorize(adminRoles), branchCtrl.getUsers);
router.post  ('/users',     authenticate, authorize(adminRoles), branchCtrl.createUser);
router.put   ('/users/:id', authenticate, authorize(adminRoles), branchCtrl.updateUser);
router.delete('/users/:id', authenticate, authorize(['super_admin']), branchCtrl.deleteUser);

// ── DEPARTMENTS ───────────────────────────────────────────────
router.get('/departments', authenticate, authorize(allRoles), branchCtrl.getDepartments);

// ── ATTENDANCE ────────────────────────────────────────────────
router.get ('/attendance',  authenticate, authorize(allRoles), branchCtrl.getAttendance);
router.post('/attendance',  authenticate, authorize(allRoles), branchCtrl.markAttendance);

module.exports = router;
