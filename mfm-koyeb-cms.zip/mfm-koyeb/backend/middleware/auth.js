// middleware/auth.js — JWT verification & role-based access
const jwt  = require('jsonwebtoken');
const db   = require('../config/database');

/**
 * Verify JWT and attach user to req.user
 */
const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer <token>

    if (!token) {
      return res.status(401).json({ success: false, message: 'Access token required' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Fetch fresh user from DB to check is_active
    const [rows] = await db.execute(
      'SELECT id, branch_id, full_name, username, email, role, is_active FROM users WHERE id = ?',
      [decoded.id]
    );

    if (!rows.length || !rows[0].is_active) {
      return res.status(401).json({ success: false, message: 'User not found or deactivated' });
    }

    req.user = rows[0];
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ success: false, message: 'Token expired. Please login again.' });
    }
    return res.status(401).json({ success: false, message: 'Invalid token' });
  }
};

/**
 * Role-based access control
 * Usage: authorize('super_admin') or authorize(['super_admin', 'branch_admin'])
 */
const authorize = (...allowedRoles) => {
  const roles = allowedRoles.flat();
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Not authenticated' });
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Access denied. Requires one of: ${roles.join(', ')}`
      });
    }
    next();
  };
};

/**
 * Branch-scope guard:
 * super_admin can access any branch.
 * Others can only access their own branch.
 */
const branchScope = (req, res, next) => {
  const requestedBranchId = parseInt(req.params.branchId || req.body.branch_id || req.query.branch_id);

  if (req.user.role === 'super_admin') return next();

  if (requestedBranchId && requestedBranchId !== req.user.branch_id) {
    return res.status(403).json({
      success: false,
      message: 'Access denied: you can only access your own branch data'
    });
  }

  // Force branch_id to their own branch for POST/PUT
  if (req.body) req.body.branch_id = req.user.branch_id;
  next();
};

module.exports = { authenticate, authorize, branchScope };
